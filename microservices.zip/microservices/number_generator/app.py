#!flask/bin/python
from flask import Flask, jsonify, make_response
import sys
from random import randint
app = Flask(__name__)

@app.errorhandler(404)
def not_found(error):
    return make_response(jsonify({'error': 'Not found'}), 404)

@app.route('/numgen', methods=['GET'])
def num_gen():
    rand = randint(0,100)
    return jsonify({"Random Numer":rand})

@app.route('/numgen/min/<int:min>/', methods=['GET'])
def num_gen_min(min):
    rand = randint(min,100)
    return jsonify({"Random Numer":rand})

@app.route('/numgen/max/<int:max>/', methods=['GET'])
def num_gen_max(max):
    rand = randint(0,max)
    return jsonify({"Random Numer":rand})

@app.route('/numgen/min/<int:min>/max/<int:max>/', methods=['GET'])
def num_gen_minmax(min, max):
    rand = randint(min,max)
    return jsonify({"Random Numer":rand})

if __name__ == '__main__':
    try:
        print(sys.argv[1])
        print("Starting number generator on port " + sys.argv[1])
        app.run(debug=True,host='127.0.0.1',port=sys.argv[1])
    except IndexError:
        print("Starting text generator 5000")
        app.run(debug=True,host='127.0.0.1',port=5000)