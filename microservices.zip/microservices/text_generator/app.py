#!flask/bin/python
from flask import Flask, jsonify, make_response
import sys
import os
from random import randint

app = Flask(__name__)

@app.errorhandler(404)
def not_found(error):
    return make_response(jsonify({'error': 'Not found'}), 404)

@app.route('/wordgen', methods=['GET'])
def word_gen():
    cwd = os.getcwd()
    file = open(cwd + "/wordlist", "r") 
    lines = file.readlines()
    file.close()
    words = lines[0].split(',')
    word = words[randint(0, len(words) - 1)].strip().lower().capitalize()
    return jsonify({"Random Word":word})

if __name__ == '__main__':
    try:
        print(sys.argv[1])
        print("Starting text generator on port " + sys.argv[1])
        app.run(debug=True,host='127.0.0.1',port=sys.argv[1])
    except IndexError:
        print("Starting text generator 5001")
        app.run(debug=True,host='127.0.0.1',port=5001)